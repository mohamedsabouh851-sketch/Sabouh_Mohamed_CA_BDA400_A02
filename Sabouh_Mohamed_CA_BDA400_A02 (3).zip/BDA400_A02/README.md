# BDA400 Assignment 2 — Preliminary Stage
Student: Sabouh Mohamed

## Requirements
R, RStudio, internet access; CRAN packages `quantmod` and `TTR` (the `zoo` dependency is installed with quantmod).

## Run
```r
install.packages(c("quantmod", "TTR"))
setwd("PATH/TO/THIS/FOLDER")
source("test_statistics.R")
source("run_analysis.R")
```

`run_analysis.R` reads `portfolio.txt`, retrieves Yahoo Finance price data, computes a 20-day moving average, mean, mode, median and sample standard deviation, prints tables and saves chart/CSV files under `output/`.

This code was created for the assignment but has NOT been executed in RStudio in this environment. Yahoo Finance requests need working internet. The accompanying Word report has honest placeholders for screenshots of your actual R/RStudio installation and execution; fill them in before submitting.

Requested GitHub repository: https://github.com/mohamedsabouh851-sketch/TechnicalAnalysis
